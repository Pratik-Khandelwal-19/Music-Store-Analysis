/*total 11 tables present in MusiconlineDB database;*/

select * from customers;
select * from employee;
select * from artist;
select * from genre;
select * from invoice;
select * from track;
select * from playlist;
select * from playlist_track;
select * from media_type;
select * from invoice_line;
select * from album;

